public class imprimirletras {
    public static void main(String[] args) {
        
        for (int cont = 97; cont <= 122; cont++){
            System.out.println((char) cont);
        }
    }
}
