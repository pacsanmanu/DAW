
    /* 
    for ( 1 ; 2 ; 3) {
            */
            /*1. Origen, entrada al for. Solo se comprueba para ver si entra al bucle 
              2. Condición para seguir o salir del bucle  
              3. Operación a ejecutar al final de cada iteración 
    */ 
