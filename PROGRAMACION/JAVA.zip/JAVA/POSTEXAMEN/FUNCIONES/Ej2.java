package POSTEXAMEN.FUNCIONES;

public class Ej2 {
    public static void Nveces(int n, String b){
        for(int i = 0; i < n; i++){
            System.out.println(b);
        }
    }

    public static void main(String[] args) {
        Nveces(4, "webo");
    }
}
