public class Main {
    public static void main(String[] args) {

        /*Esto es una función, la cual se debe llamar siempre "main"
        porque es la entrada al programa y Java la detecta así por su nombre  */

        System.out.println("Hello World!");

    }
}