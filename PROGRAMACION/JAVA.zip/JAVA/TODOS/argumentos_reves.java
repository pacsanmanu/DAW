public class argumentos_reves {
    public static void main(String[] args) {
        System.out.println(args[2] + " " + args[1] + " " + args[0]);
    }
}
