public class bucles {
    public static void main(String[] args) {
        
        int cont = 0;
        int maximo = Integer.parseInt(args[0]);
        
        while(cont > maximo){
            cont++;
            System.out.println("panda número " + cont);
        }


    }
}
