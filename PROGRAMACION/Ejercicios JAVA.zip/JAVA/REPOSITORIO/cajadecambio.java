import java.util.Scanner;
import java.lang.Math;

    //Manuel Pacheco Sánchez, 1º DAW.

public class cajadecambio {
    public static void main(String[] args) {

        // Recogemos el importe a pagar y la cantidad con la que se nos paga.

        Scanner sc = new Scanner(System.in);

        System.out.println("Introduzca el precio del importe");
        Double precio = sc.nextDouble();

        System.out.println("Introduzca el importe pagado");
        Double pago = sc.nextDouble();

        // Comprobamos si el dinero que va a pagar es suficiente, si el pago es exacto o si nos ha introducido cantidades negativas.

        if (precio > pago){
            System.out.println("El importe introducido es menor al que debe pagar.");
        }else if (precio == pago){
            System.out.println("El importe pagado es exacto. No se le tiene que devolver nada.");
        }else if (precio < 0 || pago < 0){
            System.out.println("Ha introducido alguna cantidad negativa. No le vamos a dar dinero crack");
        }else{

        // Calculamos el cambio que tenemos que devolver y lo redondeamos para quedarnos con 2 decimales.

            double cambio = Math.round((pago - precio) * 100.0) / 100.0;
            System.out.println("\nEl importe a devolver es de " + cambio + " euros. Se le devolverá en: \n");

        // Calculamos cuantas monedas o billetes se devuelven de cada tipo.
     
        /*Para cada billete o moneda, la operación a realizar es dividir el cambio entre el valor del billete
        o de la moneda, de forma que cada vez que se divida, añadimos 1 a un contador, los cuales los he
        nombrado como cont+valor de la moneda. Una vez dividido, hacemos el módulo entre el cambio y 
        la división para quedarnos con el resto en caso de que la división se pudiese realizar.
        Si el contador de la división almacena un valor de 1 o +, devolvemos un mensaje por pantalla con 
        la cantidad de monedas o billetes a devolver de ese valor.*/

            double cont500 = cambio / 500;
            cambio = ((cambio % 500) * 100) / 100;
            Math.floor(cambio);   
            if (cont500 >= 1) {System.out.println((int)cont500 + " billete/s de 500 euros");}
            
            double cont200 = cambio / 200;
            cambio = ((cambio % 200) * 100) / 100;
            Math.floor(cambio);   
            if (cont500 >= 1) {System.out.println((int)cont200 + " billete/s de 200 euros");}
            
            double cont100 = cambio / 100;
            cambio = ((cambio % 100) * 100) / 100;
            Math.floor(cambio);   
            if (cont100 >= 1) {System.out.println((int)cont100 + " billete/s de 100 euros");}
            
            double cont50 = cambio / 50;
            cambio = ((cambio % 50) * 100) / 100;  
            Math.floor(cambio); 
            if (cont50 >= 1) {System.out.println((int)cont50 + " billete/s de 50 euros");}
            
            double cont20 = cambio / 20;
            cambio = ((cambio % 20) * 100) / 100;   
            Math.floor(cambio);
            if (cont20 >= 1) {System.out.println((int)cont20 + " billete/s de 20 euros");}
            
            double cont10 = cambio / 10;
            cambio = ((cambio % 10) * 100) / 100;  
            Math.floor(cambio); 
            if (cont10 >= 1) {System.out.println((int)cont10 + " billete/s de 10 euros");}
            
            double cont5 = cambio / 5;
            cambio = ((cambio % 5) * 100) / 100;   
            Math.floor(cambio);
            if (cont5 >= 1) {System.out.println((int)cont5 + " billete/s de 5 euros");}
            
            double cont2 = cambio / 2;
            cambio = ((cambio % 2) * 100) / 100;   
            Math.floor(cambio);
            if (cont2 >= 1) {System.out.println((int)cont2 + " moneda/s de 2 euros");}
            
            double cont1 = cambio / 1;
            cambio = ((cambio % 1) * 100) / 100;   
            Math.floor(cambio);
            if (cont1 >= 1) {System.out.println((int)cont1 + " moneda/s de 1 euro");}
            
            double cont50c = cambio / 0.5;
            cambio = ((cambio % 0.5) * 100) / 100; 
            Math.floor(cambio);  
            if (cont50c >= 1) {System.out.println((int)cont50c + " moneda/s de 50 centimos");}
            
            double cont20c = cambio / 0.2;
            cambio = ((cambio % 0.2) * 100) / 100; 
            Math.floor(cambio);  
            if (cont20c >= 1) {System.out.println((int)cont20c + " moneda/s de 20 centimos");}
            
            double cont10c = cambio / 0.1;
            cambio = ((cambio % 0.1) * 100) / 100; 
            Math.floor(cambio);  
            if (cont10c >= 1) {System.out.println((int)cont10c + " moneda/s de 10 centimos");}
            
            /*A partir de los centimos inferiores a 10, he necesitado cambiar el valor de la division
            a 1 milésima menos del valor real debido a que double no arrastra valores exactos, hay
            situaciones en las que 0,05 , por más que lo redondee y que al depurar el código aparezca
            en la variable cambio con el valor de 0,05000 , se comporta como 0,0499999, por lo que 
            he considerado que lo más óptimo para que el código funcione sin utilizar cosas que no hemos visto
            sería reducir la cantidad de las divisiones al cambio entre 0,049 y así respectivamente con 
            las monedas de 5 céntimos y las de 2.*/

            double cont5c = cambio / 0.049;
            cambio = ((cambio % 0.049) * 100) / 100;
            Math.floor(cambio);   
            if (cont5c >= 1) {System.out.println((int)cont5c + " moneda/s de 5 centimos");}
            
            double cont2c = cambio / 0.019;
            cambio = ((cambio % 0.019) * 100) / 100;
            Math.floor(cambio);   
            if (cont2c >= 1) {System.out.println((int)cont2c + " moneda/s de 2 centimos");}
            
            /*Para las monedas de 1 céntimo, como double no arrastra valores exactos, calculando
            los anteriores céntimos con 1 milésima menos del valor real, al calcular el céntimo restante
            no obtengo valores exactos, pero siempre es mayor de 0,005 si es que se tiene que devolver un
            céntimo, por lo que simplemente comprobando si la variable cambio almacena un valor de más de
            0,005, sé si tengo que devolver un céntimo o no, ya que la cantidad máxima de monedas de 1 céntimo
            que se va a devolver es 1.*/

            if (cambio > 0.005){
                double cont1c = 1;
                System.out.println((int)cont1c + " moneda/s de 1 centimo");
            }

            System.out.println("\nGracias por la compra jefe.");

        } 
    }
}