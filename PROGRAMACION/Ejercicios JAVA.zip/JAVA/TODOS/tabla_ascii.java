public class tabla_ascii {
    public static void main(String[] args) {

        for (int i = 0; i < 256; i++){
            System.out.println("El  de la tabla ASCII número " + i + " es: " +(char)i);
        }
    }
}
